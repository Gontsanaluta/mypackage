# mypackage
This library was created as an example of how publish your own python packages

# How to install
...